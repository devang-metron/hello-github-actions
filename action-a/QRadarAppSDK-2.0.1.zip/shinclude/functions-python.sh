# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

retrieve_python3_version()
{
    python3 --version 2>&1
}

retrieve_python_version()
{
    python --version 2>&1
}
