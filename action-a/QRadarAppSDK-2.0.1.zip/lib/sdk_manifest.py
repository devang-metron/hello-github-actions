# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import collections
import json
import jsonschema
import os.path
import zipfile
import sdk_util
from sdk_exceptions import SdkManifestException

def load_manifest_json(workspace_path):
    with open(os.path.join(workspace_path, 'manifest.json')) as manifest_file:
        return json.load(manifest_file)

def validate_workspace_manifest(workspace_path):
    try:
        with open(os.path.join(workspace_path, 'manifest.json')) as manifest_file:
            schema = _read_manifest_schema()
            _validate_manifest(manifest_file, schema)
    except FileNotFoundError:
        raise SdkManifestException('Workspace {0} does not contain a manifest.json file'.format(workspace_path))

def validate_zip_manifest(zip_path):
    schema = _read_manifest_schema()
    try:
        with zipfile.ZipFile(zip_path) as zip_file:
            with zip_file.open('manifest.json') as manifest_file:
                _validate_manifest(manifest_file, schema)
    except zipfile.BadZipfile:
        raise SdkManifestException('{0} is not a valid zip file'.format(zip_path))
    except KeyError:
        raise SdkManifestException('{0} does not contain a manifest.json file'.format(zip_path))

def extract_uuid_from_zip_manifest(zip_path):
    try:
        with zipfile.ZipFile(zip_path) as app_zip:
            with app_zip.open('manifest.json') as manifest_file:
                manifest_json = json.load(manifest_file)
                return manifest_json['uuid']
    except zipfile.BadZipfile:
        raise SdkManifestException('{0} is not a valid zip file'.format(zip_path))
    except KeyError:
        raise SdkManifestException('{0} does not contain a manifest.json file'.format(zip_path))

def _read_manifest_schema():
    schema_file_path = sdk_util.build_sdk_path('conf', 'manifest-schema.json')
    with open(schema_file_path) as schema_file:
        return schema_file.read()

def _find_duplicate_json_keys(list_of_pairs):
    key_count = collections.Counter(k for k,_ in list_of_pairs)
    duplicate_keys = ', '.join(k for k,v in list(key_count.items()) if v>1)
    if len(duplicate_keys) != 0:
        raise SdkManifestException('Duplicate keys found in manifest.json: {}'.format(duplicate_keys))
    return dict(list_of_pairs)

def _find_missing_rest_methods(manifest_json):
    rest_methods = set()
    if 'rest_methods' in manifest_json:
        for method in manifest_json['rest_methods']:
            try:
                rest_methods.add(method['name'])
            except KeyError:
                pass

    missing_methods = []
    for field in manifest_json:
        # Only list fields need to be searched.
        if isinstance(manifest_json[field], list):
            for item in manifest_json[field]:
                if 'rest_method' in item and item['rest_method'] not in rest_methods:
                    missing_methods.append(item['rest_method'])

    return missing_methods

def _validate_manifest(manifest_file, schema):
    try:
        error_str = ''
        manifest = manifest_file.read()
        manifest_json = json.loads(manifest, object_pairs_hook=_find_duplicate_json_keys)

        validator = jsonschema.Draft4Validator(json.loads(schema))
        schema_errors = sorted(validator.iter_errors(manifest_json), key=lambda e: e.path)
        if schema_errors:
            schema_error_str = ''
            for error in schema_errors:
                schema_error_str += '\n'
                for err_thing in error.path:
                    schema_error_str += '[' + str(err_thing) + ']'
                if error.path:
                    schema_error_str += ': '
                schema_error_str += error.message
            error_str += schema_error_str

        missing_methods = _find_missing_rest_methods(manifest_json)
        if missing_methods:
            error_str += '\nThese methods are not defined in the rest_method field: ' + \
                ', '.join(method for method in missing_methods)

        if error_str:
            raise SdkManifestException('Your manifest.json contains these errors: ' + error_str)

    except (ValueError, TypeError) as err:
        raise SdkManifestException('Your manifest.json is not valid JSON:\n' + str(err))

def insert_uuid_into_manifest(uuid, workspace_path):
    manifest = load_manifest_json(workspace_path)
    manifest.update({'uuid': uuid})
    with open(os.path.join(workspace_path, 'manifest.json'), 'w') as manifest_file:
        json.dump(manifest, manifest_file, indent=2)

def uses_flask(manifest):
    try:
        return manifest['load_flask'] == 'true'
    except KeyError:
        return True

def extract_named_service_ports(manifest):
    try:
        services = manifest['services']
    except KeyError:
        return []
    ports = []
    for service in services:
        try:
            ports.append(service['port'])
        except KeyError:
            pass
    return ports
