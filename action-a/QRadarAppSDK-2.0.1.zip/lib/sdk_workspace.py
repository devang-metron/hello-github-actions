# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import os
import sdk_image
import sdk_manifest
import sdk_util

INVALID_WORKSPACE_MESSAGE = '''{0} cannot be used as a workspace name. Please specify a different directory.
Workspace names may contain lower-case letters, digits and separators.
A separator is a period, one or two underscores, or one or more dashes.
Names may not start or end with a separator.
'''

def validate_workspace_name(workspace_dir):
    try:
        sdk_image.build_image_name_from_workspace_name(workspace_dir)
    except ValueError:
        raise ValueError(INVALID_WORKSPACE_MESSAGE.format(workspace_dir))

def validate_workspace(workspace_path):
    if not os.path.isdir(workspace_path):
        raise FileNotFoundError('Directory {0} does not exist'.format(workspace_path))
    if not os.path.isdir(os.path.join(workspace_path, 'app')):
        raise FileNotFoundError('Workspace {0} does not contain an app directory'.format(workspace_path))
    sdk_manifest.validate_workspace_manifest(workspace_path)

def create_app_from_template(workspace_path, uuid):
    template_source_dir = sdk_util.build_sdk_path("template")
    print("Template source directory: " + template_source_dir)
    print("Destination directory: " + workspace_path)
    if not os.path.exists(workspace_path):
        print('Creating directories')
        os.makedirs(workspace_path)
    print('Adding template files and directories')
    sdk_util.copy_tree(template_source_dir, workspace_path)
    log_path = os.path.join(workspace_path, 'store', 'log')
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    print('Adding uuid to manifest.json')
    sdk_manifest.insert_uuid_into_manifest(uuid, workspace_path)
    print('Workspace [{0}] is ready'.format(workspace_path))
