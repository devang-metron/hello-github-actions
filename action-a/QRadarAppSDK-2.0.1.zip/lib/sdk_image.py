# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import os
import re
import shutil
import sdk_dependencies
import sdk_supervisor
import sdk_util

BASE_IMAGE_NAME = 'qradar-app-base:{0}'
BASE_IMAGE_ARCHIVE_FORMAT = 'qradar-app-base-{0}.xz'

def check_base_image(docker):
    ''' Checks if base image is in local docker registry.
        If not, loads it.
    '''
    image_repo, image_tag = read_base_image_name_components()
    if docker.registry_contains_image(image_repo, image_tag):
        print('Found base image {0}:{1}'.format(image_repo, image_tag))
        return

    print('Base image {0}:{1} is not in your Docker registry'.format(image_repo, image_tag))
    base_image_archive_path = build_base_image_archive_path(image_tag)
    print('Loading base image from {0}...'.format(base_image_archive_path))
    docker.load_image_from_archive(base_image_archive_path)
    print('Base image loaded successfully')

def generate_image_name_for_manifest():
    _, image_tag = read_base_image_name_components()
    return BASE_IMAGE_NAME.format(image_tag)

def read_base_image_name_components():
    ''' Image name format is repo:tag.
        Returns repo,tag tuple.
    '''
    version_file_path = sdk_util.build_sdk_path('base_image', 'image_name.txt')
    with open(version_file_path) as version_file:
        image_name_components = version_file.read().splitlines()[0].rpartition(':')
    if not image_name_components[0] or not image_name_components[2]:
        raise ValueError('Unable to read base image details from {0}'.format(version_file_path))
    return image_name_components[0], image_name_components[2]

def build_base_image_archive_path(image_version):
    return sdk_util.build_sdk_path('base_image', BASE_IMAGE_ARCHIVE_FORMAT.format(image_version))

def validate_image_name(image_name):
    ''' From docker tag documentation:
        Names may contain lower-case letters, digits and separators.
        A separator is defined as a period, one or two underscores, or one or more dashes.
        Names may not start or end with a separator.
    '''
    if not re.match(r'^[a-z0-9]+(?:(?:[._]|__|[-]*)?[a-z0-9]+)*$', image_name):
        raise ValueError('{0} is not a valid image name'.format(image_name))

def build_image_name_from_workspace_name(workspace_dir):
    ''' If workspace_dir converted to lowercase is a valid image name, returns that.
        If not, strips all chars except a-z and 0-9 and returns that.
        If stripping results in an empty name, raises ValueError.
    '''
    lowercase_dir = workspace_dir.lower()
    try:
        validate_image_name(lowercase_dir)
        return lowercase_dir
    except ValueError:
        stripped_name = re.sub('[^a-z0-9]', '', lowercase_dir)
        if len(stripped_name) == 0:
            raise ValueError('Unable to generate image name from directory name {0}'.format(workspace_dir))
        return stripped_name

def build(docker, image_name, workspace_path, manifest):
    check_base_image(docker)
    build_root_path = sdk_util.build_sdk_path('docker', 'build')
    prepare_image_build_directory(workspace_path, build_root_path, manifest)
    print('Building image [{0}]'.format(image_name))
    docker.build_image(image_name, build_root_path)
    print('Image [{0}] build completed successfully'.format(image_name))

def prepare_image_build_directory(workspace_path, build_root_path, manifest):
    ''' The build directory is docker/build under the SDK installation.
        This function always deletes and recreates the directory, then
        populates it with:
          + Dockerfile/scripts/config files from the SDK installation's image_files directory
          + any scripts and dependencies from the app workspace.
    '''
    print('Preparing image build directory {0}'.format(build_root_path))
    shutil.rmtree(build_root_path, ignore_errors=True)
    os.mkdir(build_root_path)

    image_files_path = sdk_util.build_sdk_path('image_files')
    sdk_util.copy_tree(image_files_path, build_root_path, 0o755)

    dependencies_cmd = sdk_dependencies.generate_dependencies_command(workspace_path)
    init_cmd = sdk_dependencies.generate_init_command(workspace_path)

    sdk_dependencies.copy_dependencies_to_build_root(dependencies_cmd, workspace_path)
    sdk_dependencies.copy_container_scripts_to_build_root(workspace_path)

    dockerfile_path = os.path.join(build_root_path, 'Dockerfile')
    sdk_util.replace_string_in_file(dockerfile_path, 'DEPENDENCIES-PLACE-HOLDER', dependencies_cmd)
    sdk_util.replace_string_in_file(dockerfile_path, 'INIT-PLACE-HOLDER', init_cmd)
    print('Using {0}'.format(dockerfile_path))

    sdk_supervisor.prepare_supervisord_conf(manifest, build_root_path)

    return build_root_path
