# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# pylint: disable=invalid-name

import argparse
import sys
from click import Abort
from sdk_actions import (create_workspace, build_image, run_app, clean, package, deploy,
                         authorize, check_app_status, cancel_app_install, delete_app)
from sdk_exceptions import SdkVersionError
from sdk_httpclient import SdkHttpClient
from sdk_version import retrieve_sdk_installed_version, perform_version_check

try:
    perform_version_check()
except SdkVersionError as sve:
    print('SDK version check failed: {0}'.format(sve))

parser = argparse.ArgumentParser(prog='qapp', formatter_class=argparse.RawTextHelpFormatter,
                                 description='Develop and manage QRadar apps')
parser.add_argument("-v", "--version", dest="show_version", help="Show version",
                    action="store_true")

subparsers = parser.add_subparsers()

parser_create = subparsers.add_parser('create', help='Instantiate a new QRadar app workspace',
                                      formatter_class=argparse.RawTextHelpFormatter)
parser_create.add_argument("-w", "--workspace", action="store", dest="workspace", default='.',
                           help="Path to workspace folder.\nDefaults to the current directory.")
parser_create.add_argument("-k", "--key", action="store", dest="key", default='',
                           help=("Application uuid key.\nLeave blank to allow the SDK "
                                 "to generate a uuid for your app."))
parser_create.set_defaults(function=create_workspace)

parser_build = subparsers.add_parser('build', help='Build a Docker image for an app',
                                     formatter_class=argparse.RawTextHelpFormatter)
parser_build.add_argument("-w", "--workspace", action="store", dest="workspace", default='.',
                          help="Path to app workspace folder.\nDefaults to the current directory.")
parser_build.set_defaults(function=build_image)

parser_run = subparsers.add_parser('run', help='Run an app locally in a Docker container',
                                   formatter_class=argparse.RawTextHelpFormatter)
parser_run.add_argument("-w", "--workspace", action="store", dest="workspace", default='.',
                        help="Path to app workspace folder.\nDefaults to the current directory.")
parser_run.add_argument("-p", "--port", action="store", dest="host_port", type=int,
                        help=("Host port to bind to port 5000 in the container.\n"
                              "If not supplied, a random port is assigned.\n"
                              "If the app does not use Flask, this argument is ignored."))
parser_run.add_argument("-d", "--development", action="store_true", dest="use_dev_env",
                        help=("Run Flask app in development mode.\n"
                              "This is useful when developing a Flask-based app."))
parser_run.add_argument("-l", "--log", action="store_true", dest="show_logs",
                        help=("Show container logs.\n"
                              "This is useful for debugging container startup."))
parser_run.set_defaults(function=run_app)

parser_clean = subparsers.add_parser('clean', help='Remove the app Docker container and, optionally, the app image',
                                     formatter_class=argparse.RawTextHelpFormatter)
parser_clean.add_argument("-w", "--workspace", action="store", dest="workspace", default='.',
                          help="Path to app workspace folder.\nDefaults to the current directory.")
parser_clean.add_argument("-i", "--image-remove", action="store_true", dest="image_remove",
                          help="Remove app image")
parser_clean.set_defaults(function=clean)

parser_package = subparsers.add_parser('package', help='Package app files into a zip archive',
                                       formatter_class=argparse.RawTextHelpFormatter)
parser_package.add_argument("-w", "--workspace", action="store", dest="workspace", default='.',
                            help="Path to app workspace folder.\nDefaults to the current directory.")
parser_package.add_argument("-p", "--package", action="store", dest="package", required=True,
                            help="Package name destination\ne.g. com.ibm.app.1.0.0.zip")
parser_package.set_defaults(function=package)

parser_deploy = subparsers.add_parser('deploy', help='Deploy app zip archive to QRadar appliance',
                                      formatter_class=argparse.RawTextHelpFormatter)
parser_deploy.add_argument("-p", "--package", action="store", dest="package", required=True,
                           help="Package to deploy\ne.g. com.ibm.app.1.0.0.zip")
parser_deploy.add_argument("-q", "--qradar-console", action="store", dest="qradar_console", required=True,
                           help="Address of QRadar console to deploy to")
parser_deploy.add_argument("-u", "--user", action="store", dest="user", required=True,
                           help="QRadar user")
parser_deploy.add_argument("-o", "--auth-user", action="store", dest="auth_user",
                           help="QRadar app authorization user")
parser_deploy.add_argument("-t", "--timeout", action="store", dest="upload_timeout", type=int,
                           default=SdkHttpClient.UPLOAD_TIMEOUT,
                           help=("The number of seconds before connection timeout occurs. Defaults to {0}.\n"
                                 "Use this when uploading a large zip archive."
                                 .format(SdkHttpClient.UPLOAD_TIMEOUT)))
parser_deploy.set_defaults(function=deploy)

parser_authorize = subparsers.add_parser('authorize',
                                         help='Finish deployment of an app by supplying an authorization user')
parser_authorize.add_argument("-q", "--qradar-console", action="store", dest="qradar_console", required=True,
                              help="Address of QRadar console to deploy to")
parser_authorize.add_argument("-u", "--user", action="store", dest="user", required=True,
                              help="QRadar user")
parser_authorize.add_argument("-a", "--application-id", action="store", dest="application_id", required=True,
                              help="ID of the QRadar app to deploy")
parser_authorize.add_argument("-o", "--auth-user", action="store", dest="auth_user",
                              help="QRadar app authorization user")
parser_authorize.set_defaults(function=authorize)

parser_status = subparsers.add_parser('status', help='Check the status of a deployed app')
parser_status.add_argument("-q", "--qradar-console", action="store", dest="qradar_console", required=True,
                           help="Address of QRadar console")
parser_status.add_argument("-u", "--user", action="store", dest="user", required=True,
                           help="QRadar user")
parser_status.add_argument("-a", "--application-id", action="store", dest="application_id", required=True,
                           help="ID of the QRadar app to check")
parser_status.set_defaults(function=check_app_status)

parser_cancel = subparsers.add_parser('cancel', help='Cancel an app deploy')
parser_cancel.add_argument("-q", "--qradar-console", action="store", dest="qradar_console", required=True,
                           help="Address of QRadar console")
parser_cancel.add_argument("-u", "--user", action="store", dest="user", required=True,
                           help="QRadar user")
parser_cancel.add_argument("-a", "--application-id", action="store", dest="application_id", required=True,
                           help="ID of the QRadar app to cancel")
parser_cancel.set_defaults(function=cancel_app_install)

parser_delete = subparsers.add_parser('delete', help='Delete a deployed app')
parser_delete.add_argument("-q", "--qradar-console", action="store", dest="qradar_console", required=True,
                           help="Address of QRadar console")
parser_delete.add_argument("-u", "--user", action="store", dest="user", required=True,
                           help="QRadar user")
parser_delete.add_argument("-a", "--application-id", action="store", dest="application_id", required=True,
                           help=("Instance ID of the QRadar app to delete.\n"
                                 "Both the app definition and instance will be deleted."))
parser_delete.set_defaults(function=delete_app)

args = parser.parse_args()

if args.show_version:
    try:
        print(retrieve_sdk_installed_version())
    except SdkVersionError as sve:
        print(sve)
    sys.exit(0)

try:
    args.function(args)
except AttributeError as ae:
    parser.print_help()
except (KeyboardInterrupt, Abort):
    print('')
