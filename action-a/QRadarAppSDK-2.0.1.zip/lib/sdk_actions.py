# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import os
import sys
import sdk_certificates
import sdk_container
import sdk_docker
import sdk_env
import sdk_image
import sdk_manifest
import sdk_package
import sdk_server
import sdk_util
import sdk_workspace
from sdk_httpclient import SdkHttpClient
from sdk_exceptions import SdkFatalError, SdkServerSslError

# SDK action entry points

def create_workspace(command_args):
    try:
        workspace_path = os.path.realpath(command_args.workspace)
        sdk_workspace.validate_workspace_name(os.path.basename(workspace_path))
        app_uuid = sdk_util.validate_or_generate_uuid(command_args.key)
        sdk_workspace.create_app_from_template(workspace_path, app_uuid)
    except (ValueError, OSError) as err:
        handle_fatal_error(err)

def build_image(command_args):
    try:
        workspace_path = os.path.realpath(command_args.workspace)
        sdk_workspace.validate_workspace(workspace_path)
        image_name = sdk_image.build_image_name_from_workspace_name(os.path.basename(workspace_path))
        manifest = sdk_manifest.load_manifest_json(workspace_path)
        docker = sdk_docker.SdkDockerClient()
        sdk_image.build(docker, image_name, workspace_path, manifest)
    except (ValueError, OSError, SdkFatalError) as err:
        handle_fatal_error(err)

def run_app(command_args):
    try:
        workspace_path = os.path.realpath(command_args.workspace)
        sdk_workspace.validate_workspace(workspace_path)
        workspace_dir = os.path.basename(workspace_path)
        image_name = sdk_image.build_image_name_from_workspace_name(workspace_dir)
        manifest = sdk_manifest.load_manifest_json(workspace_path)
        docker = sdk_docker.SdkDockerClient()
        if not docker.registry_contains_image(image_name):
            print('No image found for workspace [{0}]'.format(workspace_dir))
            sdk_image.build(docker, image_name, workspace_path, manifest)

        container_name = sdk_container.build_container_name_from_image_name(image_name)
        print('Starting container [{0}] using image [{1}]'.format(container_name, image_name))

        sdk_container.prompt_remove_running_container(docker, container_name)

        app_mounts = sdk_container.build_app_container_mounts(docker, workspace_path)
        env_vars = sdk_env.generate_env_vars(workspace_path, command_args.use_dev_env)
        requested_port_mappings = sdk_container.build_requested_port_mappings(
            manifest, command_args.host_port)

        container = docker.run(image_name, container_name, app_mounts, env_vars,
                               requested_port_mappings, command_args.show_logs)

        assigned_port_mappings = sdk_container.retrieve_assigned_port_mappings(container)
        flask_mode = sdk_container.determine_flask_mode(sdk_manifest.uses_flask(manifest),
                                                        command_args.use_dev_env)
        sdk_container.print_run_status(container, assigned_port_mappings, flask_mode, workspace_path)

    except (ValueError, OSError, SdkFatalError) as err:
        handle_fatal_error(err)

def clean(command_args):
    try:
        workspace_dir = os.path.basename(os.path.realpath(command_args.workspace))
        image_name = sdk_image.build_image_name_from_workspace_name(workspace_dir)
        container_name = sdk_container.build_container_name_from_image_name(image_name)

        docker = sdk_docker.SdkDockerClient()
        lookup_error = False

        try:
            container = docker.retrieve_container(container_name)
        except ValueError:
            lookup_error = True
            print('No container found for workspace [{0}]'.format(workspace_dir))
        else:
            print('Stopping container [{0}]'.format(container_name))
            docker.remove_container(container)
            print('Container [{0}] removal completed successfully'.format(container_name))

        if command_args.image_remove:
            if docker.registry_contains_image(image_name):
                print('Removing image [{0}]'.format(image_name))
                docker.remove_image(image_name)
                print('Image [{0}] removal completed successfully'.format(image_name))
            else:
                lookup_error = True
                print('No image found for workspace [{0}]'.format(workspace_dir))

    except (ValueError, OSError, SdkFatalError) as err:
        handle_fatal_error(err)

    if lookup_error:
        sys.exit(1)

def package(command_args):
    try:
        workspace_path = os.path.realpath(command_args.workspace)
        sdk_workspace.validate_workspace(workspace_path)
        sdk_package.create_zip(workspace_path, command_args.package)
    except (ValueError, OSError, SdkFatalError) as err:
        handle_fatal_error(err)

def check_app_status(command_args, existing_api_client = None):
    retry = (existing_api_client is None)
    try:
        sdk_util.validate_app_id(command_args.application_id)
        api_client = get_certified_api_client(command_args, existing_api_client)
        sdk_server.display_app_status(command_args.application_id, api_client)
    except SdkServerSslError as sse:
        handle_ssl_error(check_app_status, retry, sse, command_args, api_client)
    except SdkFatalError as sfe:
        handle_fatal_error(sfe)

def deploy(command_args, existing_api_client = None):
    retry = (existing_api_client is None)
    try:
        sdk_manifest.validate_zip_manifest(command_args.package)
        api_client = get_certified_api_client(command_args, existing_api_client)
        api_client.set_upload_timeout(command_args.upload_timeout)
        sdk_server.deploy_app(command_args.package, command_args.auth_user, api_client)
    except SdkServerSslError as sse:
        handle_ssl_error(deploy, retry, sse, command_args, api_client)
    except (KeyError, ValueError, SdkFatalError, OSError) as err:
        handle_fatal_error(err)

def authorize(command_args, existing_api_client = None):
    retry = (existing_api_client is None)
    try:
        sdk_util.validate_app_id(command_args.application_id)
        api_client = get_certified_api_client(command_args, existing_api_client)
        sdk_server.authorize_app(command_args.application_id, command_args.auth_user, api_client)
    except SdkServerSslError as sse:
        handle_ssl_error(authorize, retry, sse, command_args, api_client)
    except SdkFatalError as sfe:
        handle_fatal_error(sfe)

def cancel_app_install(command_args, existing_api_client = None):
    retry = (existing_api_client is None)
    try:
        sdk_util.validate_app_id(command_args.application_id)
        api_client = get_certified_api_client(command_args, existing_api_client)
        sdk_server.cancel_install(command_args.application_id, api_client)
    except SdkServerSslError as sse:
        handle_ssl_error(cancel_app_install, retry, sse, command_args, api_client)
    except SdkFatalError as sfe:
        handle_fatal_error(sfe)

def delete_app(command_args, existing_api_client = None):
    retry = (existing_api_client is None)
    try:
        sdk_util.validate_app_id(command_args.application_id)
        api_client = get_certified_api_client(command_args, existing_api_client)
        sdk_server.delete_app(command_args.application_id, api_client)
    except SdkServerSslError as sse:
        handle_ssl_error(delete_app, retry, sse, command_args, api_client)
    except SdkFatalError as sfe:
        handle_fatal_error(sfe)

# Utility functions

def handle_ssl_error(do_action, retry, ssl_error, command_args, api_client):
    if retry:
        print('')
        print(ssl_error)
        print('Refreshing CA certificate bundle for {0}'.format(command_args.qradar_console))
        sdk_util.remove_host_config(command_args.qradar_console)
        do_action(command_args, api_client)
    else:
        print('Unable to resolve SSL certificate issue')
        handle_fatal_error(ssl_error)

def handle_fatal_error(sdk_error):
    print(sdk_util.strip_errno_prefix(str(sdk_error)))
    sys.exit(1)

def get_certified_api_client(command_args, existing_api_client = None):
    cert_bundle_removed = existing_api_client is not None
    cert_path = sdk_certificates.verify_certificate_bundle(command_args.qradar_console, cert_bundle_removed)
    if existing_api_client is None:
        password = sdk_util.read_password(command_args.user)
        return SdkHttpClient(command_args.qradar_console, command_args.user, password, cert_path)
    return existing_api_client
