# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import os
import time
import sdk_util
from sdk_exceptions import SdkDockerError
import sdk_manifest

APP_ROOT = '/opt/app-root'
PATH_MANIFEST = APP_ROOT + '/manifest.json'
PATH_APP = APP_ROOT + '/app'
PATH_CONTAINER = APP_ROOT + '/container'
PATH_STORE = APP_ROOT + '/store'

def build_container_name_from_image_name(image_name):
    return 'qradar-{0}'.format(image_name)

def build_mount(docker, source_path, target_path):
    print('Mounting {0} to {1}'.format(source_path, target_path))
    return docker.build_mount(source_path, target_path)

def build_app_container_mounts(docker, workspace_path):
    manifest_mount = build_mount(docker, os.path.join(workspace_path, 'manifest.json'), PATH_MANIFEST)
    app_mount = build_mount(docker, os.path.join(workspace_path, 'app'), PATH_APP)
    store_path = os.path.join(workspace_path, 'store')
    if not os.path.exists(store_path):
        print('Creating store directory {0}'.format(store_path))
        os.mkdir(store_path)
    store_mount = build_mount(docker, store_path, PATH_STORE)
    return [manifest_mount, app_mount, store_mount]

def prompt_remove_running_container(docker, container_name):
    try:
        container = docker.retrieve_container(container_name)
    except ValueError:
        return
    print('A container named [{0}] already exists'.format(container_name))
    answer = sdk_util.read_yes_no_input('Remove existing container? (y/n): ')
    if answer == 'n':
        raise SdkDockerError('Aborting run: container [{0}] with ID {1} is still running'
                             .format(container_name, container.short_id))
    print('Removing container [{0}]'.format(container_name))
    docker.remove_container(container)
    # Wait for container to stop before proceeding, to avoid container name clash.
    time.sleep(5)
    print('Container [{0}] removal completed successfully'.format(container_name))

def print_logs(container):
    logs = container.logs(stream = True, follow = True)
    print('CONTAINER LOGS: START')
    try:
        while True:
            # next(log) return type is bytes, so we need to decode to a string.
            # We use default encoding utf-8 and ignore any errors.
            print(next(logs).decode(errors='ignore').split('\n')[0])
    except StopIteration:
        pass
    except KeyboardInterrupt:
        print('')
    print('CONTAINER LOGS: END')

def print_run_status(container, assigned_port_mappings, flask_mode, workspace_path):
    # Container status values: created|restarting|running|removing|paused|exited|dead
    if container.status in ('created', 'running'):
        print('Container [{0}] started with ID {1}'.format(container.name, container.short_id))
        for container_port, host_port in assigned_port_mappings.items():
            print('Host port {0} is mapped to container port {1}'.format(host_port, container_port))
        if flask_mode:
            print('Flask is running in {0} mode'.format(flask_mode))
            flask_host_port = assigned_port_mappings['5000/tcp']
            print('Access Flask endpoints at http://localhost:{0}'.format(flask_host_port))
    else:
        print('Container [{0}] with ID {1} has status [{2}]'
              .format(container.name, container.short_id, container.status))
    print('Use docker ps to monitor container status')
    print('Log files are located in {0}'.format(os.path.join(workspace_path, 'store', 'log')))

def determine_flask_mode(flask_loaded, use_dev_env):
    if flask_loaded:
        return 'development' if use_dev_env else 'production'
    return None

def build_requested_port_mappings(manifest, flask_host_port):
    port_mappings = {}
    if sdk_manifest.uses_flask(manifest):
        if flask_host_port is not None and flask_host_port <= 0:
            raise ValueError('Container port mapping failed: invalid port {0}'.format(flask_host_port))
        port_mappings['5000/tcp'] = flask_host_port
    service_ports = sdk_manifest.extract_named_service_ports(manifest)
    # To make Docker assign a host port, use None as the map to-value.
    # https://docker-py.readthedocs.io/en/stable/containers.html
    for port in service_ports:
        port_mappings['{0}/tcp'.format(str(port))] = None
    return port_mappings

def retrieve_assigned_port_mappings(container):
    assigned_port_mappings = {}
    for container_port, host_settings in container.ports.items():
        assigned_port_mappings[container_port] = host_settings[0]['HostPort']
    # Sort the results by host port.
    return dict(sorted(assigned_port_mappings.items(), key=lambda x: x[1]))
