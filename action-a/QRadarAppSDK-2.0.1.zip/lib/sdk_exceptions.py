# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

class SdkFatalError(Exception):
    """An error that cannot be recovered from"""

class SdkCertError(SdkFatalError):
    """Local cert bundle is not usable"""

class SdkServerConnectionError(SdkFatalError):
    """Socket connection to server failed"""

class SdkServerRequestError(SdkFatalError):
    """Request to server failed"""

class SdkServerSslError(Exception):
    """Cannot verify server connection due to an SSL error. Triggers PEM refresh."""

class SdkApiResponseError(SdkFatalError):
    """API response indicates unsuccessful operation"""

class SdkManifestException(SdkFatalError):
    """The app manifest.json file is not valid"""

class SdkDockerError(SdkFatalError):
    """A Docker error occurred"""

class SdkVersionError(Exception):
    """Error retrieving current SDK version"""

class SdkServerConfigError(SdkFatalError):
    """Error managing server configuration when using certificates"""
