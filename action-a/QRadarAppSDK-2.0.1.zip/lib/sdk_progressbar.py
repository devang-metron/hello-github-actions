from tqdm import tqdm

class ProgressBar(tqdm):
    # There is no __init__ in this class, but that's how tqdm works.
    # pylint: disable=attribute-defined-outside-init
    def progress(self, bytes_transferred, total_bytes):
        self.total = int(total_bytes)
        self.update(int(bytes_transferred - self.n))
