# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import configparser
import os

def generate_env_vars(workspace_path, use_dev_env=False):
    env_vars = {'QRADAR_APPFW_SDK': 'true'}
    if use_dev_env:
        _add_env_var(env_vars, 'FLASK_ENV', 'development')
    _add_qenv_vars(env_vars, os.path.join(workspace_path, 'qenv.ini'))
    return env_vars

def _add_qenv_vars(env_vars, qenv_ini_path):
    if not os.path.exists(qenv_ini_path):
        print('No qenv.ini file found in workspace')
        return
    print('Reading environment variables from {0}'.format(qenv_ini_path))
    var_set = False
    env_config = configparser.ConfigParser()
    env_config.read(qenv_ini_path)
    for section in env_config.sections():
        for key in env_config[section]:
            env_key = key.upper()
            value = env_config[section][key]
            if value:
                if env_key == 'QRADAR_APPFW_SDK':
                    if value.lower() != 'true':
                        print('Forcing QRADAR_APPFW_SDK=true')
                else:
                    _add_env_var(env_vars, env_key, value)
                    var_set = True
            else:
                print('Ignoring empty variable {0}'.format(env_key))
    if not var_set:
        print('No environment variables from qenv.ini were set')

def _add_env_var(env_vars, env_key, value):
    print('Setting {0}={1}'.format(env_key, value))
    env_vars[env_key] = value
