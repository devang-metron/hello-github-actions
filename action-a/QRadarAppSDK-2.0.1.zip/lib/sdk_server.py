# Licensed Materials - Property of IBM
# 5725I71-CC011829
# (C) Copyright IBM Corp. 2015, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

import json
import os
import sys
import time
import sdk_manifest
import sdk_util

API_ROOT = '/api/gui_app_framework'
ENDPOINT_APPLICATIONS = API_ROOT + '/applications'
ENDPOINT_APPLICATION = ENDPOINT_APPLICATIONS + '/{0}'
ENDPOINT_APPLICATION_INSTALL = '/api/gui_app_framework/application_creation_task'
ENDPOINT_APPLICATION_INSTALL_STATUS = ENDPOINT_APPLICATION_INSTALL + '/{0}'
ENDPOINT_APPLICATION_INSTALL_AUTH = ENDPOINT_APPLICATION_INSTALL_STATUS + '/auth'
ENDPOINT_APPLICATION_CANCEL = ENDPOINT_APPLICATION_INSTALL_STATUS + '?status=CANCELLED'
ENDPOINT_USERS_WITH_CAPABILITIES = '/api/config/access/users_with_capability_filter?capabilities={0}'
ENDPOINT_APPLICATION_GET_DEFN_ID = ENDPOINT_APPLICATION + '?fields=application_definition_id'
ENDPOINT_DEFINITIONS = API_ROOT + '/application_definitions'
ENDPOINT_DEFINITION = ENDPOINT_DEFINITIONS + '/{0}'

HEADERS_JSON = {'Accept': 'application/json', 'Content-Type': 'application/json'}
HEADERS_ZIP = {'Content-Type': 'application/zip'}

STATUS_CREATING = 'CREATING'
STATUS_UPGRADING = 'UPGRADING'
STATUS_AUTH_REQUIRED = 'AUTH_REQUIRED'
STATUS_RUNNING = 'RUNNING'
STATUS_ERROR = 'ERROR'

def display_app_status(app_id, api_client):
    response = api_client.get(request_endpoint=ENDPOINT_APPLICATION.format(app_id),
                              request_headers=HEADERS_JSON)
    app_json = response.json()
    app_status = app_json['application_state']['status']

    # See if we can get some extra status info
    if app_status in (STATUS_CREATING, STATUS_UPGRADING):
        response = api_client.get(request_endpoint=ENDPOINT_APPLICATION_INSTALL_STATUS.format(app_id),
                                  request_headers=HEADERS_JSON)
        task_status = response.json()['status']
        if task_status not in (STATUS_CREATING, STATUS_UPGRADING):
            app_status = app_status + ':' + task_status

    print(app_id + ':' + app_status)
    display_app_json_errors(app_json)

def deploy_app(package_path, auth_user_name, api_client):
    app_uuid = sdk_manifest.extract_uuid_from_zip_manifest(package_path)
    app_id = get_app_id_for_uuid(app_uuid, api_client)
    zip_in_memory = sdk_util.load_zip_into_memory(package_path)
    if app_id is None:
        new_install(package_path, auth_user_name, api_client, zip_in_memory)
    else:
        upgrade_install(package_path, app_id, auth_user_name, api_client, zip_in_memory)

def authorize_app(app_id, auth_user_name, api_client):
    handle_auth_request(str(app_id), auth_user_name, api_client)

def cancel_install(app_id, api_client):
    api_client.post(request_endpoint=ENDPOINT_APPLICATION_CANCEL.format(app_id),
                    request_headers=HEADERS_JSON)
    print("Cancel request accepted for application {0}".format(str(app_id)))

def delete_app(app_id, api_client):
    response = api_client.get(request_endpoint=ENDPOINT_APPLICATION_GET_DEFN_ID.format(app_id),
                              request_headers=HEADERS_JSON)
    app_definition_id = response.json()['application_definition_id']
    print('Deleting application {0}'.format(str(app_id)))
    api_client.delete(request_endpoint=ENDPOINT_DEFINITION.format(app_definition_id))
    print('Application {0} has been deleted'.format(str(app_id)))

def display_app_json_errors(app_json):
    has_errors = False
    try:
        for error in app_json['application_state']['error_messages_json']:
            print(error['message'])
            has_errors = True
    except KeyError:
        pass
    return has_errors

def get_app_id_for_uuid(app_uuid, api_client):
    response = api_client.get(request_endpoint=ENDPOINT_APPLICATIONS,
                              request_headers=HEADERS_JSON)
    response_json = response.json()
    for app in response_json:
        if 'uuid' in app["manifest"]:
            if app["manifest"]["uuid"] == app_uuid:
                if app["application_state"]["status"] == "ERROR":
                    return None
                return app["application_state"]["application_id"]
    return None

def new_install(package_path, auth_user_name, api_client, zip_in_memory):
    print("Application fresh install detected")
    print("Uploading {} {} bytes".format(package_path, os.path.getsize(package_path)))
    response = api_client.post(request_endpoint=ENDPOINT_APPLICATION_INSTALL,
                               request_headers=HEADERS_ZIP,
                               request_package=zip_in_memory.read())
    task_json = response.json()
    app_id = task_json['application_id']
    print("Installing application {}".format(app_id))
    finish_install(task_json, app_id, api_client, auth_user_name, expected_status=STATUS_CREATING)

def upgrade_install(package_path, app_id, auth_user_name, api_client, zip_in_memory):
    print("Application upgrade detected")
    print("Uploading {} {} bytes".format(package_path, os.path.getsize(package_path)))
    response = api_client.put(request_endpoint=ENDPOINT_APPLICATION.format(app_id),
                              request_headers=HEADERS_ZIP,
                              request_package=zip_in_memory.read())
    task_json = response.json()
    finish_install(task_json, app_id, api_client, auth_user_name, expected_status=STATUS_UPGRADING)

def finish_install(task_json, app_id, api_client, auth_user_name, expected_status):
    task_status = task_json['status']
    print("Application {}: {}".format(app_id, task_status))
    if task_status == expected_status:
        wait_for_deploy_end(app_id, api_client)
    elif task_status == STATUS_AUTH_REQUIRED:
        handle_auth_request(str(app_id), auth_user_name, api_client)

def handle_auth_request(app_id, auth_user_name, api_client):
    capable_users = retrieve_capable_users(app_id, api_client)
    try:
        auth_user_id = retrieve_auth_user_id(auth_user_name, capable_users)
    except ValueError:
        print('Deployment of application {0} is waiting for authorization'.format(app_id))
        return

    auth_body = {}
    auth_body['user_id'] = auth_user_id
    api_client.post(request_endpoint=ENDPOINT_APPLICATION_INSTALL_AUTH.format(app_id),
                    request_headers=HEADERS_JSON,
                    request_json=auth_body)
    wait_for_deploy_end(app_id, api_client)

def retrieve_capable_users(app_id, api_client):
    # What capabilities is the app requesting?
    auth_response = api_client.get(request_endpoint=ENDPOINT_APPLICATION_INSTALL_AUTH.format(app_id),
                                   request_headers=HEADERS_JSON)
    requested_capabilities = json.dumps(auth_response.json()['capabilities'])
    print('Application {} is requesting capabilities {}'.format(app_id, requested_capabilities))

    # Which QRadar users have those capabilities?
    users_response = api_client.get(request_endpoint=ENDPOINT_USERS_WITH_CAPABILITIES.format(requested_capabilities),
                                    request_headers={'Allow-Hidden': 'true'})
    return users_response.json()

def retrieve_auth_user_id(auth_user_name, capable_users):
    auth_user_id = get_auth_user_id_from_name(auth_user_name, capable_users)
    if auth_user_id != 0:
        return auth_user_id

    # The caller must choose an authorization user from the list.
    print('These users have the requested capabilities:')
    for capable_user in capable_users:
        print('  {0}'.format(capable_user['username']))

    if len(capable_users) == 1:
        # Only one authorization user is available to select, so a simple yes or no response will do.
        # "No" means don't proceed with the deployment.
        answer = sdk_util.read_yes_no_input('Use {0} as the authorization user? (y/n): '
                                            .format(capable_users[0]['username']))
        if answer == 'y':
            return capable_users[0]['id']
        raise ValueError

    while True:
        # The caller must select one of the capable user names.
        # An empty response means don't proceed with the deployment, subject to a confirmatory "yes".
        selected_user_name = input('Select a user: ').strip()
        if len(selected_user_name) == 0:
            if sdk_util.read_yes_no_input('Stop deployment? (y/n): ') == 'y':
                raise ValueError
        else:
            for capable_user in capable_users:
                if capable_user['username'] == selected_user_name:
                    return capable_user['id']
            print('User name {0} not recognized'.format(selected_user_name))

def get_auth_user_id_from_name(auth_user_name, capable_users):
    if auth_user_name is None:
        return 0

    # The caller supplied an authorization user. Is is valid?
    for capable_user in capable_users:
        if capable_user['username'] == auth_user_name:
            print('Using supplied authorization user {0}'.format(auth_user_name))
            return capable_user['id']

    print('Supplied authorization user {0} does not have the requested capabilities'.format(auth_user_name))
    return 0

def wait_for_deploy_end(app_id, api_client):
    # Loop over the application_creation_endpoint until the deploy finishes.
    # Note that any error message is not committed to the installed_application table
    # until the very end of the deployment, so there is no point in trying to print
    # error details inside this loop.
    task_status = STATUS_CREATING
    while task_status in (STATUS_CREATING, STATUS_UPGRADING):
        task_response = api_client.get(request_endpoint=ENDPOINT_APPLICATION_INSTALL_STATUS.format(app_id),
                                       request_headers=HEADERS_JSON)
        task_json = task_response.json()
        task_status = task_json['status']
        print("Application {}: {}".format(app_id, task_status))
        if task_status in (STATUS_CREATING, STATUS_UPGRADING):
            time.sleep(5)

    # Now call the applications endpoint to get the final status of the deployment.
    app_response = api_client.get(request_endpoint=ENDPOINT_APPLICATION.format(app_id),
                                  request_headers=HEADERS_JSON)
    app_json = app_response.json()

    app_final_status = app_json['application_state']['status']
    additional_app_details = ''

    if app_final_status != STATUS_ERROR:
        additional_app_details = ' ' + app_json['manifest']['version']

    print("Final application state: {}{}".format(app_final_status, additional_app_details))
    has_errors = display_app_json_errors(app_json)

    if app_final_status == STATUS_ERROR or has_errors:
        sys.exit(1)
